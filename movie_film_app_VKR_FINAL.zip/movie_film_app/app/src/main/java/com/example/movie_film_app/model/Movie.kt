package com.example.movie_film_app.model

import java.io.Serializable

data class Movie(
    val id: Int,
    val title: String,
    val genre: String,
    val country: String,
    val year: Int,
    val posterResName: String,
    val ageRating: Int,
    val actors: List<String>,
    val links: Map<String, String> = emptyMap(),
    val isUserAdded: Boolean = false
) : Serializable
