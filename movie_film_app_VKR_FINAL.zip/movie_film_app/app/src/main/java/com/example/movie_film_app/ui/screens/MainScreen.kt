package com.example.movie_film_app.ui.screens

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.movie_film_app.ui.theme.MovieFilmAppTheme
import com.example.movie_film_app.viewModel.MovieViewModel
import com.example.movie_film_app.model.Movie
import com.example.movie_film_app.ui.components.FilterSection
import com.example.movie_film_app.ui.components.MovieCard
import androidx.compose.ui.platform.LocalContext

@Composable
fun MainScreen(viewModel: MovieViewModel = viewModel(), onMovieClick: (Movie) -> Unit) {
    val context = LocalContext.current
    val movies by viewModel.filteredMovies.collectAsState()
    val isDarkTheme = isSystemInDarkTheme()
    val showFilters by viewModel.showFilters
    val currentFilter by viewModel.filter.collectAsState()
    val allMovies by viewModel.allMovies.collectAsState()
    val genres = remember(allMovies) { allMovies.map { it.genre }.distinct().sorted() }
    val countries = remember(allMovies) { allMovies.map { it.country }.distinct().sorted() }
    val years = remember(allMovies) { allMovies.map { it.year }.distinct().sorted() }
    val yearRanges = remember(years) {
        years.map { it / 10 * 10 }.distinct().sorted().map { it..(it + 9) }
    }

    LaunchedEffect(Unit) {
        viewModel.loadLocalMovies(context)
    }

    MovieFilmAppTheme(darkTheme = isDarkTheme) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background
        ) {
            Column(
                modifier = Modifier
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(bottom = 12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Movie,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Список фильмов",
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }

                OutlinedTextField(
                    value = currentFilter.searchQuery,
                    onValueChange = { viewModel.updateFilter(currentFilter.copy(searchQuery = it)) },
                    label = { Text("Поиск по названию") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp)
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterButton(
                        text = "Фильтры",
                        modifier = Modifier.weight(1f)
                    ) { viewModel.toggleFilterVisibility() }
                }

                FilterButton(
                    text = "Очистить фильтры",
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp)
                ) {
                    viewModel.clearFilters()
                }

                if (showFilters && allMovies.isNotEmpty()) {
                    FilterSection(
                        filter = currentFilter,
                        onFilterChange = { viewModel.updateFilter(it) },
                        onClose = { viewModel.toggleFilterVisibility() },
                        genres = genres,
                        countries = countries,
                        yearRanges = yearRanges
                    )
                }

                LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(movies) { movie ->
                        MovieCard(
                            movie = movie,
                            onClick = { onMovieClick(movie) },
                            onDelete = {
                                if (movie.isUserAdded) {
                                    viewModel.removeMovie(movie)
                                }
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun FilterButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(
            containerColor = MaterialTheme.colorScheme.secondary.copy(alpha = 0.3f),
            contentColor = MaterialTheme.colorScheme.onSecondary
        ),
        modifier = modifier.height(42.dp)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelLarge,
            textAlign = TextAlign.Center
        )
    }
}