package com.example.movie_film_app.ui.screens

import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import com.example.movie_film_app.model.Movie

@Composable
fun AddMovieForm(
    onMovieAdded: (Movie) -> Unit,
    onCancel: () -> Unit
) {
    var title by remember { mutableStateOf("") }
    var genre by remember { mutableStateOf("") }
    var country by remember { mutableStateOf("") }
    var year by remember { mutableStateOf("") }
    var ageRating by remember { mutableStateOf("") }
    var posterResName by remember { mutableStateOf("") }
    var actorsInput by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val scrollState = rememberScrollState()
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(scrollState)
        ) {
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Название") },
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = genre,
                onValueChange = { genre = it },
                label = { Text("Жанр") },
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = country,
                onValueChange = { country = it },
                label = { Text("Страна") },
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = year,
                onValueChange = { year = it },
                label = { Text("Год") },
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = ageRating,
                onValueChange = { ageRating = it },
                label = { Text("Возрастной рейтинг (например, 12+)") },
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = actorsInput,
                onValueChange = { actorsInput = it },
                label = { Text("Актёры (через запятую)") },
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = posterResName,
                onValueChange = { posterResName = it },
                label = { Text("Имя ресурса постера (без .png)") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        errorMessage?.let {
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = it, color = MaterialTheme.colorScheme.error)
        }

        Spacer(modifier = Modifier.height(16.dp))

        Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Button(onClick = {
                if (title.isEmpty() || genre.isEmpty() || country.isEmpty() || year.isEmpty() || ageRating.isEmpty() || actorsInput.isEmpty() || posterResName.isEmpty()) {
                    errorMessage = "Пожалуйста, заполните все поля!"
                    return@Button
                }

                val yearInt = year.toIntOrNull()
                val ageRatingInt = ageRating.toIntOrNull()

                if (yearInt == null || ageRatingInt == null) {
                    errorMessage = "Пожалуйста, укажите правильный год и возрастной рейтинг."
                    return@Button
                }

                val posterId = context.resources.getIdentifier(posterResName, "drawable", context.packageName)
                if (posterId == 0) {
                    errorMessage = "Не найден ресурс с изображением постера. Пожалуйста, убедитесь, что указано правильное имя."
                    return@Button
                }

                val movie = Movie(
                    id = System.currentTimeMillis().toInt(),
                    title = title,
                    genre = genre,
                    country = country,
                    year = yearInt,
                    ageRating = ageRatingInt,
                    posterResName = posterResName,
                    actors = actorsInput.split(",").map { it.trim() },
                    isUserAdded = true
                )

                onMovieAdded(movie)

                errorMessage = null
            }) {
                Text("Сохранить")
            }

            OutlinedButton(onClick = onCancel) {
                Text("Отмена")
            }
        }
    }
}

